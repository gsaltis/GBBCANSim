/*****************************************************************************!
 * Function : MainDisplayBlocker
 *****************************************************************************/
function
MainDisplayBlocker()
{
  document.getElementById("MainBlocker").style.visibility = "visible";
}

