/*****************************************************************************!
 * Function : MainDisplayMessage
 *****************************************************************************/
function
MainDisplayMessage(InMessage)
{
  MainDisplayMessageColor(InMessage, "#000000"); 
}

