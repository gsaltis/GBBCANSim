/*****************************************************************************!
 * Function : MainHideBlocker
 *****************************************************************************/
function
MainHideBlocker()
{
  document.getElementById("MainBlocker").style.visibility = "hidden";
}

