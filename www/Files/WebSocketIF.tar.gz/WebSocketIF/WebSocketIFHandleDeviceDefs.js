/*****************************************************************************!
 * Function : WebSocketIFHandleDeviceDefs
 *****************************************************************************/
function
WebSocketIFHandleDeviceDefs(InDeviceDefs)
{
  MainDeviceDefs = InDeviceDefs;
}


