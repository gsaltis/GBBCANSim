/*****************************************************************************!
 * Function : WebSocketIFSendDeviceDefRegRequestStart
 *****************************************************************************/
function
WebSocketIFSendDeviceDefRegRequestStart
()
{
  WebSocketIFDeviceIndex = 0;
  WebSocketIFSendDeviceDefRegRequest();
}


