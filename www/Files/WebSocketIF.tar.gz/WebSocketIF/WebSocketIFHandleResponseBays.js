/*****************************************************************************!
 * Function : WebSocketIFHandleResponseBayTypes
 *****************************************************************************/
function
WebSocketIFHandleResponseBayTypes(InBayTypes)
{
  MainBayTypes = InBayTypes;
}

