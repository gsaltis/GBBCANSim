/*****************************************************************************!
 * Function : WebSocketIFHandleFuseBreakerTypes
 *****************************************************************************/
function
WebSocketIFHandleFuseBreakerTypes(InFuseBreakerTypes)
{
  MainFuseBreakerTypes = InFuseBreakerTypes;
}

