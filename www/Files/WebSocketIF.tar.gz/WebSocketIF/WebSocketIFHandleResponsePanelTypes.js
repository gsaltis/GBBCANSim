/*****************************************************************************!
 * Function : WebSocketIFHandleResponsePanelTypes
 *****************************************************************************/
function
WebSocketIFHandleResponsePanelTypes(InPanelTypes)
{
  MainPanelTypes = InPanelTypes;
}

