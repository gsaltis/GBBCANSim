/*****************************************************************************!
 * Function : WebSocketIFRequestGetBayTypes
 *****************************************************************************/
function
WebSocketIFRequestGetBayTypes()
{
   WebSocketIFSendSimpleRequest("getbaytypes");
}


