/*****************************************************************************!
 * Function : WebSocketIFGetNextID
 *****************************************************************************/
function 
WebSocketIFGetNextID()
{
  WebSocketIFNextID++;
  return WebSocketIFNextID;
}

