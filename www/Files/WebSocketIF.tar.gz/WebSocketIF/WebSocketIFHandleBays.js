/*****************************************************************************!
 * Function : WebSocketIFHandleBays
 *****************************************************************************/
function
WebSocketIFHandleBays(InBays)
{
  MainBays = InBays;
  BaysPopulateWindow();
}


