/*****************************************************************************
 * FILE NAME    : WebSocketIF.js
 * DATE         : June 11 2020
 * PROJECT      : BDFB Simulator
 * COPYRIGHT    : Copyright (C) 2020 by Vertiv Company
 *****************************************************************************/

/*****************************************************************************!
 * Local Data 
 *****************************************************************************/
var WebSocketIFConnection = null;
var WebSocketIFNextID = 1;
var WebSocketIFDeviceIndex = 0;

